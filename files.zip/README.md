# Web Agency Multi-Agent System for Claude Code

A primary orchestrator + 6 specialized sub-agents designed for website development and management. Give the primary agent a goal, and it plans, delegates, and coordinates the team to get it done.

---

## File Structure

```
your-project/
├── CLAUDE.md                  ← Primary orchestrator (Project Director)
├── progress.md                ← Shared progress tracker
├── .claude/
│   └── agents/
│       ├── architect.md       ← Systems design & specs
│       ├── frontend.md        ← UI components & styling
│       ├── backend.md         ← APIs, database, integrations
│       ├── content.md         ← Copy, SEO, structured data
│       ├── qa.md              ← Testing & audit
│       └── devops.md          ← Build, deploy, infrastructure
└── docs/
    ├── specs/                 ← Architect outputs spec files here
    ├── qa/                    ← QA outputs reports here
    ├── content/               ← Content drafts (optional)
    └── devops/                ← Devops runbooks (optional)
```

---

## Installation

1. **Copy `CLAUDE.md`** to the root of your project repo (or merge with your existing `CLAUDE.md`)

2. **Create the agents directory** and copy all agent `.md` files:
   ```bash
   mkdir -p .claude/agents
   cp agents/*.md .claude/agents/
   ```

3. **Copy `progress.md`** to the repo root

4. **Create the docs directories:**
   ```bash
   mkdir -p docs/specs docs/qa docs/content docs/devops
   ```

5. **Open Claude Code** in your project and start with a goal.

> **Note:** Agent files go in `.claude/agents/` for project-scoped agents (shared via version control with your team). To make agents available across all your projects instead, copy them to `~/.claude/agents/`.

---

## How to Use

Just talk to **Mira** by name. She handles planning, delegation, and coordination.

**In a Claude Code session:**
```
Hey Mira, today I want to add a contact form with Resend email integration
Mira, redesign the homepage — it should feel modern and load faster
Hey Mira, set up a blog with Contentful CMS, including SEO metadata
Mira, the mobile navigation is broken below 768px, fix it
```

**Or explicitly invoke her:**
```
@agent-mira [your goal here]
```

**Or run a full session as Mira (best for larger goals):**
```bash
claude --agent mira
```
When you do this, the entire session runs as Mira — describe your goal and she moves.

---

## How It Works

```
You give a goal
       ↓
Project Director reads the codebase (Explore subagent)
       ↓
Architect designs the system → produces spec in docs/specs/
       ↓
Frontend + Backend work (parallel if independent, sequential if dependent)
       ↓
Content adds copy, SEO metadata, structured data
       ↓
DevOps updates build/deploy config if needed
       ↓
QA audits everything → produces report in docs/qa/
       ↓
Project Director reviews QA report, re-dispatches fixes if needed
       ↓
Goal marked COMPLETE in progress.md
```

---

## Agent Models & Costs

| Agent | Default Model | Rationale |
|---|---|---|
| architect | Sonnet | Needs strong reasoning for design decisions |
| frontend | Sonnet | Complex component logic and pattern matching |
| backend | Sonnet | Security-critical, needs careful code generation |
| content | Haiku | Primarily text generation, fast and cheap |
| qa | Sonnet | Needs to reason about correctness |
| devops | Sonnet | Infrastructure changes require careful reasoning |

You can change any agent's model by editing the `model:` field in its frontmatter.

---

## Parallel Execution Tips

Claude Code will automatically decide when to run agents in parallel based on your `CLAUDE.md` routing rules. To explicitly run agents in parallel, you can use Agent Teams mode:

```bash
claude --experimental-agent-teams
```

This allows sub-agents to run in separate context windows and communicate through the shared `progress.md` file.

---

## Customizing Agents

Each agent is a plain Markdown file. Customize them by:
- Editing the `description:` to adjust when Claude auto-delegates to them
- Changing `model:` to trade off capability vs. speed/cost
- Editing `tools:` to restrict what an agent can do (e.g., give QA read-only access)
- Adding project-specific conventions, tech stack details, or style guides to the system prompt body

---

## Extending the Team

Add new specialist agents by creating new `.md` files in `.claude/agents/`. Good candidates for web projects:

- `analytics.md` — GA4/GTM setup, event tracking, conversion goals
- `i18n.md` — Internationalization, translation management
- `security.md` — Security audits, dependency scanning, CSP headers
- `performance.md` — Core Web Vitals optimization, bundle analysis
